package com.chinmay.springbootexperiment.reactspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
